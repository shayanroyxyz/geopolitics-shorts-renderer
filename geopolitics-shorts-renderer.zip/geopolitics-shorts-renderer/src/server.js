import http from "node:http";
import { randomUUID } from "node:crypto";
import { spawn } from "node:child_process";
import { mkdir, readFile, rm, stat, writeFile } from "node:fs/promises";
import path from "node:path";
import os from "node:os";

const PORT = Number(process.env.PORT || 10000);
const TOKEN = process.env.API_TOKEN || "";
const MAX_SCENES = Number(process.env.MAX_SCENES || 8);
const MAX_DURATION = Number(process.env.MAX_DURATION_SECONDS || 60);
const JOB_DIR = path.join(os.tmpdir(), "shorts-jobs");
await mkdir(JOB_DIR, { recursive: true });
const jobs = new Map();

function send(res, status, data) {
  res.writeHead(status, {"content-type":"application/json","cache-control":"no-store"});
  res.end(JSON.stringify(data));
}
function clean(s, n) { return String(s ?? "").replace(/[\\r\\n\\t]+/g," ").replace(/\\s+/g," ").trim().slice(0,n); }
function esc(s) { return s.replace(/\\\\/g,"\\\\\\\\").replace(/:/g,"\\\\:").replace(/'/g,"\\\\'").replace(/,/g,"\\\\,").replace(/%/g,"\\\\%").replace(/;/g,"\\\\;"); }
function body(req) {
  return new Promise((resolve,reject) => {
    let raw = "";
    req.on("data", c => { raw += c; if (raw.length > 1000000) reject(new Error("JSON body exceeds 1 MB.")); });
    req.on("end", () => { try { resolve(JSON.parse(raw || "{}")); } catch { reject(new Error("Invalid JSON body.")); } });
    req.on("error", reject);
  });
}
function ffmpeg(args) {
  return new Promise((resolve,reject) => {
    const p = spawn("ffmpeg",args,{stdio:["ignore","ignore","pipe"]});
    let err = "";
    p.stderr.on("data",d => { err += d.toString(); if(err.length>10000) err=err.slice(-10000); });
    p.on("error",reject);
    p.on("close",code => code===0 ? resolve() : reject(new Error(err || `ffmpeg exit ${code}`)));
  });
}
async function render(id, scenes) {
  const dir = path.join(JOB_DIR,id); await mkdir(dir,{recursive:true});
  const clips=[]; let total=0;
  for(let i=0;i<scenes.length;i++){
    const s=scenes[i], dur=Math.max(3,Math.min(10,Number(s.duration||6))); total+=dur;
    if(total>MAX_DURATION) throw new Error(`Total duration exceeds ${MAX_DURATION}s.`);
    const title=esc(clean(s.title,70)), subtitle=esc(clean(s.subtitle,120)), label=esc(clean(s.label||`WORLD BRIEF / 0${i+1}`,45));
    const out=path.join(dir,`scene-${i}.mp4`), bg=["0x10151D","0x15151B","0x111A1B","0x1A1515"][i%4];
    const vf=[
      "drawbox=x=54:y=105:w=6:h=150:color=0xFF6A35:t=fill",
      `drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf:text='${label}':fontcolor=0xFF6A35:fontsize=23:x=76:y=112`,
      `drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf:text='${title}':fontcolor=0xF5F0E6:fontsize=58:line_spacing=12:x=76:y=310`,
      `drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf:text='${subtitle}':fontcolor=0xD5D8DC:fontsize=30:line_spacing=9:x=76:y=650`,
      "drawbox=x=76:y=1120:w=568:h=4:color=0x424852:t=fill",
      `drawbox=x=76:y=1120:w=${Math.round(568*(i+1)/scenes.length)}:h=4:color=0xFF6A35:t=fill`
    ].join(",");
    await ffmpeg(["-y","-f","lavfi","-i",`color=c=${bg}:s=720x1280:r=25:d=${dur}`,"-vf",vf,"-c:v","libx264","-preset","ultrafast","-crf","25","-pix_fmt","yuv420p","-an",out]);
    clips.push(out);
  }
  const concat=path.join(dir,"concat.txt");
  await writeFile(concat,clips.map(p=>`file '${p}'`).join("\\n"));
  const file=path.join(dir,"final.mp4");
  await ffmpeg(["-y","-f","concat","-safe","0","-i",concat,"-c","copy","-movflags","+faststart",file]);
  return {file,bytes:(await stat(file)).size,duration:total};
}

http.createServer(async(req,res)=>{
  const u=new URL(req.url,`http://${req.headers.host||"localhost"}`);
  if(req.method==="GET" && u.pathname==="/health") return send(res,200,{ok:true,service:"geopolitics-shorts-renderer"});
  if(!TOKEN || req.headers.authorization!==`Bearer ${TOKEN}`) return send(res,401,{error:"Unauthorized"});
  if(req.method==="POST" && u.pathname==="/render"){
    try{
      const b=await body(req);
      if(!Array.isArray(b.scenes)||b.scenes.length<1||b.scenes.length>MAX_SCENES) return send(res,400,{error:`Provide 1-${MAX_SCENES} scenes.`});
      const scenes=b.scenes.map(s=>({title:clean(s.title,70),subtitle:clean(s.subtitle,120),label:clean(s.label,45),duration:Number(s.duration||6)}));
      if(scenes.some(s=>!s.title)) return send(res,400,{error:"Every scene needs a title."});
      const id=randomUUID(); jobs.set(id,{id,status:"queued",createdAt:new Date().toISOString()});
      render(id,scenes).then(r=>jobs.set(id,{...jobs.get(id),status:"completed",...r})).catch(e=>jobs.set(id,{...jobs.get(id),status:"failed",error:e.message.slice(0,1000)}));
      return send(res,202,{jobId:id,status:"queued",statusUrl:`/jobs/${id}`,fileUrl:`/jobs/${id}/file`});
    }catch(e){return send(res,400,{error:e.message});}
  }
  const m=u.pathname.match(/^\\/jobs\\/([a-f0-9-]+)(\\/file)?$/);
  if(req.method==="GET"&&m){
    const j=jobs.get(m[1]); if(!j)return send(res,404,{error:"Job not found; temporary jobs reset after restart."});
    if(m[2]==="/file"){
      if(j.status!=="completed")return send(res,409,{error:`Job status: ${j.status}`});
      const data=await readFile(j.file); res.writeHead(200,{"content-type":"video/mp4","content-length":data.length,"content-disposition":`attachment; filename="short-${j.id}.mp4"`}); return res.end(data);
    }
    return send(res,200,{jobId:j.id,status:j.status,bytes:j.bytes,duration:j.duration,error:j.error,fileUrl:j.status==="completed"?`/jobs/${j.id}/file`:undefined});
  }
  return send(res,404,{error:"Not found"});
}).listen(PORT,"0.0.0.0",()=>console.log(`Renderer listening on ${PORT}`));

process.on("SIGTERM",async()=>{try{await rm(JOB_DIR,{recursive:true,force:true});}catch{}process.exit(0);});

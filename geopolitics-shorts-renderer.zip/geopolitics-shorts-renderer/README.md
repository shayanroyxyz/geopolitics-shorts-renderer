# Geopolitics Shorts Renderer

Dockerized Node.js + FFmpeg API that creates vertical 720×1280 MP4 typography-led clips from a storyboard.

## Honest limitations
This is a starter renderer, not a full newsroom. It does not fetch news, fact-check claims, create data charts, generate narration, or include licensed music. It creates clean dark editorial scenes with orange accents and text overlays. Add only facts checked against reliable sources.

Render Free web services sleep after 15 minutes without inbound traffic and use ephemeral storage. Jobs and MP4s may disappear after a restart, spin-down, or redeploy. Free instances are for testing, not production. Download each completed MP4 promptly. See https://render.com/docs/free.

## Deploy
1. Put this folder in a GitHub repository.
2. In Render choose New → Blueprint and connect the repository, or create a Docker Web Service.
3. Set `API_TOKEN` in Render Environment to a long random secret. Do not commit it or paste it into public chats.
4. Deploy; your URL will be `https://SERVICE-NAME.onrender.com`.
5. Check `/health`.

## API
All endpoints except `/health` require `Authorization: Bearer YOUR_API_TOKEN`.

POST `/render`, JSON:
```json
{"scenes":[{"label":"WORLD BRIEF / 01","title":"A NEW POWER BALANCE","subtitle":"A concise verified explanation.","duration":6}]}
```
Returns a job ID. Poll `GET /jobs/JOB_ID` until completed, then download `GET /jobs/JOB_ID/file` as binary MP4.

In Make, map the downloaded binary into YouTube upload's file data field, not the JSON job-status response.

## Local test
```bash
docker build -t shorts-renderer .
docker run --rm -p 10000:10000 -e API_TOKEN='replace-this-secret' shorts-renderer
```
